<?php
/**
 * CAMP MARL – Shop auf EIN Testprodukt reduzieren (nur lokale Test-/Vorschauumgebung).
 *
 * Aufruf:  wp eval-file dev/single-product.php            (reduzieren)
 *          wp eval-file dev/single-product.php restore    (zuvor ausgeblendete Produkte wieder veröffentlichen)
 *
 * - Aktualisiert das vorhandene Produkt „Dometic Residence AIR“ (Slug bleibt unverändert,
 *   damit keine Permalinks ändern) zu „Dometic Residence AIR Stay 11-19“ mit den Angaben
 *   aus der Kundenanzeige. Bilder: unverändert die gelieferten Originalfotos des Produkts.
 * - Setzt alle anderen veröffentlichten Produkte auf „Entwurf“ (nichts wird gelöscht;
 *   Kategorien, Bilder, Bestellungen und Kunden bleiben unberührt). Die ausgeblendeten
 *   Produkte werden mit `_cm_single_product_hidden` markiert und sind per `restore`
 *   wiederherstellbar.
 * - Preis 2.599,00 € = VORLÄUFIGER Testpreis aus der Kundenanzeige (Verhandlungsbasis,
 *   vom Kunden noch zu bestätigen). Kein Streichpreis, kein Sale.
 * - Versand: bestehende WooCommerce-Konfiguration, keine eigenen Kosten.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

if ( 'local' !== wp_get_environment_type() && 'development' !== wp_get_environment_type() ) {
	WP_CLI::error( 'Abbruch: nur in lokalen Test-/Vorschauumgebungen (WP_ENVIRONMENT_TYPE=local).' );
}

$mode = isset( $args[0] ) ? (string) $args[0] : '';
$main = get_page_by_path( 'dometic-residence-air', OBJECT, 'product' );
if ( ! $main ) {
	WP_CLI::error( 'Produkt „dometic-residence-air“ fehlt – zuerst seed-test-data.php ausführen.' );
}

$flagged = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'draft',
		'numberposts' => -1,
		'fields'      => 'ids',
		'meta_key'    => '_cm_single_product_hidden', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'  => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
	)
);

if ( 'restore' === $mode ) {
	foreach ( $flagged as $id ) {
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		delete_post_meta( $id, '_cm_single_product_hidden' );
	}
	WP_CLI::success( count( $flagged ) . ' Produkte wiederhergestellt.' );
	return;
}

// 1) Testprodukt aktualisieren.
$p = wc_get_product( $main->ID );
$p->set_name( 'Dometic Residence AIR Stay 11-19' );
$p->set_status( 'publish' );
$p->set_regular_price( '2599.00' );
$p->set_sale_price( '' );
$p->set_stock_status( 'instock' );
$p->set_short_description( '<p>Das Dometic Residence AIR Stay Vorzelt nutzt wie die Residence-Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens.</p>' );
$p->set_description(
	'<p>Das Dometic Residence Stay Vorzelt nutzt wie die Residence Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens und verfügt über die gleichen großen Fenster sowie ein integriertes dreiseitiges Vordach.</p>'
);
$attr = new WC_Product_Attribute();
$attr->set_name( 'Zustand' );
$attr->set_options( array( 'Neu' ) );
$attr->set_visible( true );
$attr->set_variation( false );
$p->set_attributes( array( $attr ) );
$p->save();
if ( taxonomy_exists( 'product_brand' ) ) {
	wp_set_object_terms( $p->get_id(), 'dometic', 'product_brand' );
}
update_post_meta( $p->get_id(), '_cm_price_unconfirmed', '1' ); // Dokumentation: Preis noch vom Kunden zu bestätigen.

// 2) Alle anderen veröffentlichten Produkte auf Entwurf (reversibel).
$others = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'numberposts' => -1,
		'fields'      => 'ids',
		'exclude'     => array( $main->ID ),
	)
);
foreach ( $others as $id ) {
	update_post_meta( $id, '_cm_single_product_hidden', '1' );
	wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
}
wc_delete_product_transients();
WP_CLI::success( sprintf( 'Testprodukt aktualisiert, %d weitere Produkte auf Entwurf gesetzt.', count( $others ) ) );
