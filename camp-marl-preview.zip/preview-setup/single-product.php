<?php
/**
 * CAMP MARL – Shop auf EIN Testprodukt reduzieren (nur lokale Test-/Vorschauumgebung).
 *
 * Aufruf:  wp eval-file dev/single-product.php            (idempotent: neun Produkte, übrige auf Entwurf)
 *          wp eval-file dev/single-product.php restore    (zuvor ausgeblendete Produkte wieder veröffentlichen)
 *
 * - Legt NEUN einfache Produkte „Dometic Residence AIR Stay 11 … 19“ an (je eine Größe, SKU =
 *   Dometic-Artikelnummer). Das bestehende Produkt (ID/Slug unverändert) wird zu Größe 11;
 *   Bilder, Galerie, Beschreibung, Kategorie und Marke sind bei allen neun identisch.
 * - Setzt alle anderen veröffentlichten Produkte auf „Entwurf“ (nichts wird gelöscht;
 *   Kategorien, Bilder, Bestellungen und Kunden bleiben unberührt). Die ausgeblendeten
 *   Produkte werden mit `_cm_single_product_hidden` markiert und sind per `restore`
 *   wiederherstellbar.
 * - Preis 2.599,00 € = VORLÄUFIGER Testpreis aus der Kundenanzeige (Verhandlungsbasis,
 *   vom Kunden noch zu bestätigen). Kein Streichpreis, kein Sale.
 * - Versand: bestehende WooCommerce-Konfiguration, keine eigenen Kosten.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

if ( 'local' !== wp_get_environment_type() && 'development' !== wp_get_environment_type() ) {
	WP_CLI::error( 'Abbruch: nur in lokalen Test-/Vorschauumgebungen (WP_ENVIRONMENT_TYPE=local).' );
}

$mode = isset( $args[0] ) ? (string) $args[0] : '';
$main = get_page_by_path( 'dometic-residence-air', OBJECT, 'product' );
if ( ! $main ) {
	WP_CLI::error( 'Produkt „dometic-residence-air“ fehlt – zuerst seed-test-data.php ausführen.' );
}

$flagged = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'draft',
		'numberposts' => -1,
		'fields'      => 'ids',
		'meta_key'    => '_cm_single_product_hidden', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'  => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
	)
);

if ( 'restore' === $mode ) {
	foreach ( $flagged as $id ) {
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		delete_post_meta( $id, '_cm_single_product_hidden' );
	}
	WP_CLI::success( count( $flagged ) . ' Produkte wiederhergestellt.' );
	return;
}

// 1) Neun eigenständige EINFACHE Produkte „Dometic Residence AIR Stay 11 … 19“ (je eine Größe).
//    Das bisherige Produkt (ID/URL bleiben) wird zu Größe 11. Gleiche Bilder/Galerie/Beschreibung,
//    vorläufiger Testpreis 2.599,00 € (Jens muss Preise, Größen und Bestände vor dem Livegang bestätigen).
//    SKUs = Dometic-Artikelnummern aus dem Katalog. Keine Varianten, keine Breitenangaben.
$skus = array(
	11 => '9120002654',
	12 => '9120002655',
	13 => '9120002369',
	14 => '9120002370',
	15 => '9120002371',
	16 => '9120002372',
	17 => '9120002373',
	18 => '9120002374',
	19 => '9120002375',
);
$desc_short = '<p>Das Dometic Residence AIR Stay Vorzelt nutzt wie die Residence-Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens.</p>';
$desc_long  = '<p>Das Dometic Residence Stay Vorzelt nutzt wie die Residence Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens und verfügt über die gleichen großen Fenster sowie ein integriertes dreiseitiges Vordach.</p>';

// Bisherige Variantenstruktur auflösen (nur die selbst angelegten Größenvarianten dieses Produkts).
$old = wc_get_product( $main->ID );
if ( $old && $old->is_type( 'variable' ) ) {
	foreach ( $old->get_children() as $child_id ) {
		wp_delete_post( $child_id, true );
	}
	wp_set_object_terms( $main->ID, 'simple', 'product_type' );
}
// Vorlage-Daten (Bilder, Kategorien, Marke, Versandklasse) vom bestehenden Produkt.
$tpl = wc_get_product( $main->ID );
$img = $tpl->get_image_id();
$gal = $tpl->get_gallery_image_ids();
$cats = $tpl->get_category_ids();
$ship = $tpl->get_shipping_class_id();

$ids = array();
foreach ( $skus as $n => $sku ) {
	$existing = (int) wc_get_product_id_by_sku( $sku );
	if ( ! $existing && 11 === $n ) {
		$existing = $main->ID;
	}
	if ( ! $existing ) {
		$by_slug = get_page_by_path( 'dometic-residence-air-stay-' . $n, OBJECT, 'product' );
		$existing = $by_slug ? $by_slug->ID : 0;
	}
	$prod = new WC_Product_Simple( $existing );
	$prod->set_name( 'Dometic Residence AIR Stay ' . $n );
	if ( ! $existing ) {
		$prod->set_slug( 'dometic-residence-air-stay-' . $n );
	}
	$prod->set_status( 'publish' );
	$prod->set_sku( $sku );
	$prod->set_regular_price( '2599.00' );
	$prod->set_sale_price( '' );
	$prod->set_manage_stock( false );
	$prod->set_stock_status( 'instock' );
	$prod->set_short_description( $desc_short );
	$prod->set_description( $desc_long );
	$prod->set_category_ids( $cats );
	$prod->set_image_id( $img );
	$prod->set_gallery_image_ids( $gal );
	$prod->set_shipping_class_id( $ship );
	$prod->set_menu_order( $n );
	$cond = new WC_Product_Attribute();
	$cond->set_name( 'Zustand' );
	$cond->set_options( array( 'Neu' ) );
	$cond->set_visible( true );
	$cond->set_variation( false );
	$prod->set_attributes( array( $cond ) );
	$prod->set_default_attributes( array() );
	$id = $prod->save();
	if ( taxonomy_exists( 'product_brand' ) ) {
		wp_set_object_terms( $id, 'dometic', 'product_brand' );
	}
	update_post_meta( $id, '_cm_price_unconfirmed', '1' );
	$ids[ $n ] = $id;
}

// 2) Alle anderen veröffentlichten Produkte auf Entwurf (reversibel).
$others = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'numberposts' => -1,
		'fields'      => 'ids',
		'exclude'     => array_values( $ids ),
	)
);
foreach ( $others as $id ) {
	update_post_meta( $id, '_cm_single_product_hidden', '1' );
	wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
}
wc_delete_product_transients();
WP_CLI::success( sprintf( 'Testprodukt aktualisiert, %d weitere Produkte auf Entwurf gesetzt.', count( $others ) ) );
