<?php
/**
 * CAMP MARL – Shop auf EIN Testprodukt reduzieren (nur lokale Test-/Vorschauumgebung).
 *
 * Aufruf:  wp eval-file dev/single-product.php            (reduzieren)
 *          wp eval-file dev/single-product.php restore    (zuvor ausgeblendete Produkte wieder veröffentlichen)
 *
 * - Aktualisiert das vorhandene Produkt „Dometic Residence AIR“ (Slug bleibt unverändert,
 *   damit keine Permalinks ändern) zu „Dometic Residence AIR Stay 11-19“ mit den Angaben
 *   aus der Kundenanzeige. Bilder: unverändert die gelieferten Originalfotos des Produkts.
 * - Setzt alle anderen veröffentlichten Produkte auf „Entwurf“ (nichts wird gelöscht;
 *   Kategorien, Bilder, Bestellungen und Kunden bleiben unberührt). Die ausgeblendeten
 *   Produkte werden mit `_cm_single_product_hidden` markiert und sind per `restore`
 *   wiederherstellbar.
 * - Preis 2.599,00 € = VORLÄUFIGER Testpreis aus der Kundenanzeige (Verhandlungsbasis,
 *   vom Kunden noch zu bestätigen). Kein Streichpreis, kein Sale.
 * - Versand: bestehende WooCommerce-Konfiguration, keine eigenen Kosten.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

if ( 'local' !== wp_get_environment_type() && 'development' !== wp_get_environment_type() ) {
	WP_CLI::error( 'Abbruch: nur in lokalen Test-/Vorschauumgebungen (WP_ENVIRONMENT_TYPE=local).' );
}

$mode = isset( $args[0] ) ? (string) $args[0] : '';
$main = get_page_by_path( 'dometic-residence-air', OBJECT, 'product' );
if ( ! $main ) {
	WP_CLI::error( 'Produkt „dometic-residence-air“ fehlt – zuerst seed-test-data.php ausführen.' );
}

$flagged = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'draft',
		'numberposts' => -1,
		'fields'      => 'ids',
		'meta_key'    => '_cm_single_product_hidden', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'  => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
	)
);

if ( 'restore' === $mode ) {
	foreach ( $flagged as $id ) {
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		delete_post_meta( $id, '_cm_single_product_hidden' );
	}
	WP_CLI::success( count( $flagged ) . ' Produkte wiederhergestellt.' );
	return;
}

// 1) Testprodukt aktualisieren.
$p = wc_get_product( $main->ID );
$p->set_name( 'Dometic Residence AIR Stay' );
$p->set_status( 'publish' );
$p->set_short_description( '<p>Das Dometic Residence AIR Stay Vorzelt nutzt wie die Residence-Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens.</p>' );
$p->set_description(
	'<p>Das Dometic Residence Stay Vorzelt nutzt wie die Residence Tour-Serie die gesamte Länge der Vorzeltschiene des Wohnwagens und verfügt über die gleichen großen Fenster sowie ein integriertes dreiseitiges Vordach.</p>'
);
$p->save();

// 2) In ein variables Produkt umwandeln: globales Attribut „Größe“ (pa_groesse), Größen 11–19.
//    Die Größenliste sind die vom Kunden gewünschten TESTOPTIONEN – tatsächliche Verfügbarkeit
//    muss Jens vor dem Livegang bestätigen. Keine Bestandszahlen, keine Aufpreise.
$sizes = range( 11, 19 );
if ( ! wc_attribute_taxonomy_id_by_name( 'groesse' ) ) {
	wc_create_attribute( array( 'name' => 'Größe', 'slug' => 'groesse', 'type' => 'select', 'order_by' => 'menu_order' ) );
	register_taxonomy( 'pa_groesse', array( 'product' ), array() );
}
if ( ! taxonomy_exists( 'pa_groesse' ) ) {
	register_taxonomy( 'pa_groesse', array( 'product' ), array() );
}
foreach ( $sizes as $i => $n ) {
	$slug = 'groesse-' . $n;
	if ( ! get_term_by( 'slug', $slug, 'pa_groesse' ) ) {
		wp_insert_term( (string) $n, 'pa_groesse', array( 'slug' => $slug ) );
	}
}
$slugs = array_map( static fn( $n ) => 'groesse-' . $n, $sizes );

wp_set_object_terms( $main->ID, 'variable', 'product_type' );
$p = new WC_Product_Variable( $main->ID );
$attr = new WC_Product_Attribute();
$attr->set_id( wc_attribute_taxonomy_id_by_name( 'groesse' ) );
$attr->set_name( 'pa_groesse' );
$attr->set_options( array_map( static fn( $sl ) => (int) get_term_by( 'slug', $sl, 'pa_groesse' )->term_id, $slugs ) );
$attr->set_position( 0 );
$attr->set_visible( true );
$attr->set_variation( true );
$cond = new WC_Product_Attribute();
$cond->set_name( 'Zustand' );
$cond->set_options( array( 'Neu' ) );
$cond->set_position( 1 );
$cond->set_visible( true );
$cond->set_variation( false );
$p->set_attributes( array( $attr, $cond ) );
$p->set_default_attributes( array() ); // keine Vorauswahl
$p->set_regular_price( '' );
$p->save();
wp_set_object_terms( $p->get_id(), $slugs, 'pa_groesse' );

$existing = array();
foreach ( $p->get_children() as $child_id ) {
	$v = wc_get_product( $child_id );
	if ( $v ) {
		$key = (string) ( $v->get_attributes()['pa_groesse'] ?? '' );
		if ( isset( $existing[ $key ] ) ) {
			wp_delete_post( $v->get_id(), true ); // Duplikat einer eigenen Variante entfernen
			continue;
		}
		$existing[ $key ] = $v;
	}
}
foreach ( $slugs as $slug ) {
	$var = isset( $existing[ $slug ] ) ? $existing[ $slug ] : new WC_Product_Variation();
	$var->set_parent_id( $p->get_id() );
	$var->set_attributes( array( 'pa_groesse' => $slug ) );
	$var->set_status( 'publish' );
	$var->set_regular_price( '2599.00' ); // vorläufiger Testpreis, je Variante im Backend änderbar
	$var->set_sale_price( '' );
	$var->set_manage_stock( false );
	$var->set_stock_status( 'instock' );
	$var->save();
}
WC_Product_Variable::sync( $p->get_id() );
wc_delete_product_transients( $p->get_id() );
if ( taxonomy_exists( 'product_brand' ) ) {
	wp_set_object_terms( $p->get_id(), 'dometic', 'product_brand' );
}
update_post_meta( $p->get_id(), '_cm_price_unconfirmed', '1' ); // Dokumentation: Preis noch vom Kunden zu bestätigen.

// 2) Alle anderen veröffentlichten Produkte auf Entwurf (reversibel).
$others = get_posts(
	array(
		'post_type'   => 'product',
		'post_status' => 'publish',
		'numberposts' => -1,
		'fields'      => 'ids',
		'exclude'     => array( $main->ID ),
	)
);
foreach ( $others as $id ) {
	update_post_meta( $id, '_cm_single_product_hidden', '1' );
	wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
}
wc_delete_product_transients();
WP_CLI::success( sprintf( 'Testprodukt aktualisiert, %d weitere Produkte auf Entwurf gesetzt.', count( $others ) ) );
