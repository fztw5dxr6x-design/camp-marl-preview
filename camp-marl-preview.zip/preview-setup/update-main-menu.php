<?php
/**
 * CAMP MARL – Hauptmenü nach dem Dometic-Katalog (Inhaltsverzeichnis 2027).
 *
 * Aufruf:  wp eval-file dev/update-main-menu.php
 *
 * - Legt die fünf Produktkategorien an, falls sie fehlen (leer, ohne Produktzuordnung).
 * - Ersetzt im Menü „Hauptmenü“ (Position „Hauptnavigation“) nur die Menüeinträge:
 *   Vorzelte (Statische Vorzelte · Driveaway-Vorzelte · Vorzelt-Übersicht) ·
 *   Pavillons und Zubehör · Zubehör · Möbel,
 *   danach Beratung · Über uns · Kontakt.
 * - Ändert, löscht oder verschiebt KEINE Produkte oder bestehende Kategorien.
 *
 * Wiederholbar: Mehrfaches Ausführen ergibt dasselbe Menü.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

$log = static function ( string $msg ): void {
	if ( class_exists( 'WP_CLI' ) ) {
		WP_CLI::log( $msg );
	} else {
		echo esc_html( $msg ) . "\n";
	}
};

// Bezeichnungen exakt wie im Katalog. Slug => Name.
$categories = array(
	'statische-vorzelte'   => 'Statische Vorzelte',
	'driveaway-vorzelte'   => 'Driveaway-Vorzelte',
	'pavillons-und-zubehoer' => 'Pavillons und Zubehör',
	'zubehoer'             => 'Zubehör',
	'moebel'               => 'Möbel',
);

if ( ! taxonomy_exists( 'product_cat' ) ) {
	$log( 'WooCommerce fehlt – Abbruch.' );
	return;
}

// „Statische Vorzelte“ und „Driveaway-Vorzelte“ gehören zum Vorzelt-Bereich (Übersicht: Kategorie „Vorzelte“).
$tent_root   = get_term_by( 'slug', 'vorzelte', 'product_cat' );
$tent_parent = $tent_root ? (int) $tent_root->term_id : 0;
$tent_slugs  = array( 'statische-vorzelte', 'driveaway-vorzelte' );

$order = 10;
foreach ( $categories as $slug => $name ) {
	$parent = in_array( $slug, $tent_slugs, true ) ? $tent_parent : 0;
	if ( ! term_exists( $slug, 'product_cat' ) ) {
		$res = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug, 'parent' => $parent ) );
		if ( ! is_wp_error( $res ) ) {
			update_term_meta( $res['term_id'], 'order', $order );
			$log( "Kategorie angelegt: {$name}" );
		}
	}
	if ( $parent ) {
		$existing = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $existing && 0 === (int) $existing->parent ) {
			wp_update_term( $existing->term_id, 'product_cat', array( 'parent' => $parent ) );
			$log( "Kategorie unter „Vorzelte“ eingeordnet: {$name}" );
		}
	}
	$order += 10;
}

// Schlagwort „Neu“: Produkte, die im Backend so markiert werden, erscheinen unter „Neue Vorzelte“.
if ( taxonomy_exists( 'product_tag' ) && ! term_exists( 'neu', 'product_tag' ) ) {
	wp_insert_term( 'Neu', 'product_tag', array( 'slug' => 'neu' ) );
	$log( 'Schlagwort „Neu“ angelegt.' );
}

// Menü holen oder anlegen.
$locations = get_theme_mod( 'nav_menu_locations', array() );
$menu      = ! empty( $locations['primary'] ) ? wp_get_nav_menu_object( $locations['primary'] ) : false;
if ( ! $menu ) {
	$menu = wp_get_nav_menu_object( 'Hauptmenü' );
}
if ( ! $menu ) {
	$menu_id = wp_create_nav_menu( 'Hauptmenü' );
	$menu    = wp_get_nav_menu_object( $menu_id );
}
$menu_id = (int) $menu->term_id;

// Nur die Menüeinträge ersetzen.
foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $item ) {
	wp_delete_post( $item->ID, true );
}

$pages = static function ( string $template ): int {
	$ids = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'meta_key' => '_wp_page_template', 'meta_value' => $template, 'fields' => 'ids', 'numberposts' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	return $ids ? (int) $ids[0] : 0;
};

// Menüeintrag für eine Produktkategorie anlegen (optional als Unterpunkt).
$add_cat = static function ( string $slug, string $title, int $parent_item = 0 ) use ( $menu_id ): int {
	$term = get_term_by( 'slug', $slug, 'product_cat' );
	if ( ! $term ) {
		return 0;
	}
	return (int) wp_update_nav_menu_item(
		$menu_id,
		0,
		array(
			'menu-item-title'     => $title,
			'menu-item-object'    => 'product_cat',
			'menu-item-object-id' => $term->term_id,
			'menu-item-type'      => 'taxonomy',
			'menu-item-parent-id' => $parent_item,
			'menu-item-status'    => 'publish',
		)
	);
};

// Oberkategorie „Vorzelte“ mit drei Unterpunkten (Übersicht = bestehende Kategorie „Vorzelte“).
$tents = $add_cat( 'vorzelte', 'Vorzelte' );
if ( $tents ) {
	$add_cat( 'statische-vorzelte', 'Statische Vorzelte', $tents );
	$add_cat( 'driveaway-vorzelte', 'Driveaway-Vorzelte', $tents );
	$add_cat( 'vorzelte', 'Vorzelt-Übersicht', $tents );
}
$add_cat( 'pavillons-und-zubehoer', 'Pavillons und Zubehör' );
$add_cat( 'zubehoer', 'Zubehör' );
$add_cat( 'moebel', 'Möbel' );
foreach ( array(
	'templates/page-advice.php'  => array( 'Beratung', 'cm-nav-consult' ),
	'templates/page-about.php'   => array( 'Über uns', '' ),
	'templates/page-contact.php' => array( 'Kontakt', '' ),
) as $template => list( $title, $class ) ) {
	$page_id = $pages( $template );
	if ( $page_id ) {
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => $title,
				'menu-item-classes'   => $class,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			)
		);
	}
}

$locations['primary'] = $menu_id;
set_theme_mod( 'nav_menu_locations', $locations );
$log( 'Hauptmenü aktualisiert (' . count( wp_get_nav_menu_items( $menu_id ) ) . ' Einträge).' );
