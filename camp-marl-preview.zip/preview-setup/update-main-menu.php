<?php
/**
 * CAMP MARL – Hauptmenü nach dem Dometic-Katalog (Inhaltsverzeichnis 2027).
 *
 * Aufruf:  wp eval-file dev/update-main-menu.php
 *
 * - Legt die fünf Produktkategorien an, falls sie fehlen (leer, ohne Produktzuordnung).
 * - Ersetzt im Menü „Hauptmenü“ (Position „Hauptnavigation“) nur die Menüeinträge:
 *   Statische Vorzelte · Driveaway-Vorzelte · Pavillons und Zubehör · Zubehör · Möbel,
 *   danach Beratung · Über uns · Kontakt.
 * - Ändert, löscht oder verschiebt KEINE Produkte oder bestehende Kategorien.
 *
 * Wiederholbar: Mehrfaches Ausführen ergibt dasselbe Menü.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

$log = static function ( string $msg ): void {
	if ( class_exists( 'WP_CLI' ) ) {
		WP_CLI::log( $msg );
	} else {
		echo esc_html( $msg ) . "\n";
	}
};

// Bezeichnungen exakt wie im Katalog. Slug => Name.
$categories = array(
	'statische-vorzelte'   => 'Statische Vorzelte',
	'driveaway-vorzelte'   => 'Driveaway-Vorzelte',
	'pavillons-und-zubehoer' => 'Pavillons und Zubehör',
	'zubehoer'             => 'Zubehör',
	'moebel'               => 'Möbel',
);

if ( ! taxonomy_exists( 'product_cat' ) ) {
	$log( 'WooCommerce fehlt – Abbruch.' );
	return;
}

$order = 10;
foreach ( $categories as $slug => $name ) {
	if ( ! term_exists( $slug, 'product_cat' ) ) {
		$res = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
		if ( ! is_wp_error( $res ) ) {
			update_term_meta( $res['term_id'], 'order', $order );
			$log( "Kategorie angelegt: {$name}" );
		}
	}
	$order += 10;
}

// Menü holen oder anlegen.
$locations = get_theme_mod( 'nav_menu_locations', array() );
$menu      = ! empty( $locations['primary'] ) ? wp_get_nav_menu_object( $locations['primary'] ) : false;
if ( ! $menu ) {
	$menu = wp_get_nav_menu_object( 'Hauptmenü' );
}
if ( ! $menu ) {
	$menu_id = wp_create_nav_menu( 'Hauptmenü' );
	$menu    = wp_get_nav_menu_object( $menu_id );
}
$menu_id = (int) $menu->term_id;

// Nur die Menüeinträge ersetzen.
foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $item ) {
	wp_delete_post( $item->ID, true );
}

$pages = static function ( string $template ): int {
	$ids = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'meta_key' => '_wp_page_template', 'meta_value' => $template, 'fields' => 'ids', 'numberposts' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	return $ids ? (int) $ids[0] : 0;
};

foreach ( $categories as $slug => $name ) {
	$term = get_term_by( 'slug', $slug, 'product_cat' );
	if ( $term ) {
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => $name,
				'menu-item-object'    => 'product_cat',
				'menu-item-object-id' => $term->term_id,
				'menu-item-type'      => 'taxonomy',
				'menu-item-status'    => 'publish',
			)
		);
	}
}
foreach ( array(
	'templates/page-advice.php'  => 'Beratung',
	'templates/page-about.php'   => 'Über uns',
	'templates/page-contact.php' => 'Kontakt',
) as $template => $title ) {
	$page_id = $pages( $template );
	if ( $page_id ) {
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => $title,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page_id,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			)
		);
	}
}

$locations['primary'] = $menu_id;
set_theme_mod( 'nav_menu_locations', $locations );
$log( 'Hauptmenü aktualisiert (' . count( wp_get_nav_menu_items( $menu_id ) ) . ' Einträge).' );
