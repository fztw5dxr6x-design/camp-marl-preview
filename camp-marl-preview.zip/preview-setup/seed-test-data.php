<?php
/**
 * CAMP MARL – NUR LOKALE TESTDATEN (niemals auf der Live-Seite ausführen).
 *
 * Aufruf:  wp eval-file dev/seed-test-data.php
 *
 * Legt an:
 *  - „Dometic Residence AIR“ mit den gelieferten Originalfotos, OHNE Preis und
 *    ohne erfundene Beschreibung (Preis auf Anfrage – echte Daten folgen).
 *  - Klar markierte „[TEST]“-Produkte mit Testpreisen und Testbildern, um
 *    Warenkorb, Varianten, Bestand, Angebot, Finder und Kasse zu prüfen.
 *  - Testversand (0 €), Vorkasse, Steuersatz 19 % und Gutschein TEST10.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

if ( 'local' !== wp_get_environment_type() && 'development' !== wp_get_environment_type() ) {
	WP_CLI::error( 'Abbruch: Testdaten nur in lokalen Umgebungen (WP_ENVIRONMENT_TYPE=local).' );
}

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

$dir = __DIR__ . '/seed-assets';

$import_image = static function ( string $path, string $alt, int $parent = 0 ): int {
	$existing = get_posts(
		array(
			'post_type'   => 'attachment',
			'meta_key'    => '_cm_seed_source',
			'meta_value'  => basename( $path ),
			'fields'      => 'ids',
			'numberposts' => 1,
		)
	);
	if ( $existing ) {
		return (int) $existing[0];
	}
	$tmp = wp_tempnam( basename( $path ) );
	copy( $path, $tmp );
	$id = media_handle_sideload( array( 'name' => basename( $path ), 'tmp_name' => $tmp ), $parent, $alt );
	if ( is_wp_error( $id ) ) {
		WP_CLI::warning( $id->get_error_message() );
		return 0;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	update_post_meta( $id, '_cm_seed_source', basename( $path ) );
	return (int) $id;
};

/** Testbild erzeugen (neutral, klar als Testbild erkennbar). */
$test_image = static function ( string $label, string $color ) use ( $dir ): string {
	$file = sys_get_temp_dir() . '/cm-test-' . sanitize_title( $label ) . '.png';
	$s    = 300;
	$im   = imagecreatetruecolor( $s, $s );
	imagefill( $im, 0, 0, imagecolorallocate( $im, 0xf1, 0xf1, 0xe7 ) );
	[ $r, $g, $b ] = sscanf( $color, '#%02x%02x%02x' );
	$c = imagecolorallocate( $im, $r, $g, $b );
	imagefilledpolygon( $im, array( 150, 60, 250, 220, 50, 220 ), $c );
	imagefilledpolygon( $im, array( 150, 150, 180, 220, 120, 220 ), imagecolorallocate( $im, 0xf1, 0xf1, 0xe7 ) );
	$ink = imagecolorallocate( $im, 0x5d, 0x61, 0x55 );
	imagestring( $im, 5, 113, 240, 'TESTBILD', $ink );
	$big = imagecreatetruecolor( 1000, 1000 );
	imagecopyresampled( $big, $im, 0, 0, 0, 0, 1000, 1000, $s, $s );
	imagepng( $big, $file );
	return $file;
};

$cat = static fn( string $slug ): array => ( $t = get_term_by( 'slug', $slug, 'product_cat' ) ) ? array( (int) $t->term_id ) : array();

$find = static function ( string $sku ): int {
	return (int) wc_get_product_id_by_sku( $sku );
};

// --- Steuer, Versand, Zahlung, Gutschein (nur lokal) -------------------------
update_option( 'woocommerce_calc_taxes', 'yes' );
update_option( 'woocommerce_prices_include_tax', 'yes' );
update_option( 'woocommerce_tax_display_shop', 'incl' );
update_option( 'woocommerce_tax_display_cart', 'incl' );
update_option( 'woocommerce_tax_based_on', 'shipping' );
global $wpdb;
if ( ! $wpdb->get_var( "SELECT tax_rate_id FROM {$wpdb->prefix}woocommerce_tax_rates WHERE tax_rate_country = 'DE' AND tax_rate_class = ''" ) ) {
	WC_Tax::_insert_tax_rate(
		array(
			'tax_rate_country'  => 'DE',
			'tax_rate'          => '19.0000',
			'tax_rate_name'     => 'MwSt.',
			'tax_rate_priority' => 1,
			'tax_rate_compound' => 0,
			'tax_rate_shipping' => 1,
			'tax_rate_order'    => 0,
			'tax_rate_class'    => '',
		)
	);
	WP_CLI::log( 'Steuersatz DE 19 % (Testannahme, bitte bestätigen).' );
}

foreach ( array( 'kleinteile' => 'Kleinteile', 'standardpaket' => 'Standardpaket', 'sperrgut' => 'Sperrgut' ) as $slug => $name ) {
	if ( ! term_exists( $slug, 'product_shipping_class' ) ) {
		wp_insert_term( $name, 'product_shipping_class', array( 'slug' => $slug, 'description' => 'Versandklasse – Kosten werden nach Vorgabe von CAMP MARL hinterlegt.' ) );
	}
}

$zones = WC_Shipping_Zones::get_zones();
if ( ! array_filter( $zones, static fn( $z ) => 'Deutschland' === $z['zone_name'] ) ) {
	$zone = new WC_Shipping_Zone();
	$zone->set_zone_name( 'Deutschland' );
	$zone->add_location( 'DE', 'country' );
	$zone->save();
	$instance = $zone->add_shipping_method( 'flat_rate' );
	update_option(
		'woocommerce_flat_rate_' . $instance . '_settings',
		array(
			'title'      => 'Testversand (Kosten folgen)',
			'tax_status' => 'taxable',
			'cost'       => '0',
		)
	);
	WP_CLI::log( 'Versandzone Deutschland mit Testversand 0 € (Platzhalter).' );
}

update_option(
	'woocommerce_bacs_settings',
	array(
		'enabled'      => 'yes',
		'title'        => 'Vorkasse (Banküberweisung)',
		'description'  => 'Du überweist den Betrag nach der Bestellung. Die Bankverbindung erhältst du in der Bestellbestätigung.',
		'instructions' => 'TESTUMGEBUNG – Bankverbindung wird von CAMP MARL hinterlegt.',
	)
);

if ( ! wc_get_coupon_id_by_code( 'TEST10' ) ) {
	$coupon = new WC_Coupon();
	$coupon->set_code( 'TEST10' );
	$coupon->set_discount_type( 'percent' );
	$coupon->set_amount( 10 );
	$coupon->set_description( 'Nur lokale Testumgebung' );
	$coupon->save();
}

// --- Echtes Produkt: Dometic Residence AIR (ohne Preis/erfundene Daten) -------
if ( ! get_page_by_path( 'dometic-residence-air', OBJECT, 'product' ) ) {
	$alts   = array(
		'01' => 'Dometic Residence AIR Luftvorzelt mit geschlossenen Seitenwänden',
		'02' => 'Dometic Residence AIR mit Panoramafenstern und Vorhängen',
		'03' => 'Dometic Residence AIR in der Seitenansicht mit geöffnetem Eingang',
		'04' => 'Dometic Residence AIR in der Frontansicht',
		'05' => 'Dometic Residence AIR mit seitlichem Anbau',
		'06' => 'Detailansicht: Luftschlauch und Belüftung im Dachbereich',
		'07' => 'Detailansicht: Vorhang am Fenster',
		'08' => 'Detailansicht: Gurtbefestigung unter dem Dach',
		'09' => 'Dometic Residence AIR am Wohnwagen auf einem Campingplatz',
	);
	$images = array();
	foreach ( $alts as $n => $alt ) {
		$file = "{$dir}/residence-air-{$n}.jpg";
		if ( file_exists( $file ) ) {
			$images[] = $import_image( $file, $alt );
		}
	}
	$p = new WC_Product_Simple();
	$p->set_name( 'Dometic Residence AIR' );
	$p->set_slug( 'dometic-residence-air' );
	$p->set_status( 'publish' );
	$p->set_short_description( '<p>[Platzhalter] Die geprüfte Produktbeschreibung, technische Daten, Größen und Preise werden von CAMP MARL geliefert.</p>' );
	$p->set_description( '<p>[Platzhalter] Ausführliche Beschreibung folgt.</p>' );
	$p->set_category_ids( $cat( 'luftvorzelte' ) );
	$p->set_image_id( $images[0] ?? 0 );
	$p->set_gallery_image_ids( array_slice( $images, 1 ) );
	$p->set_shipping_class_id( (int) ( get_term_by( 'slug', 'sperrgut', 'product_shipping_class' )->term_id ?? 0 ) );
	$id = $p->save();
	if ( taxonomy_exists( 'product_brand' ) ) {
		wp_set_object_terms( $id, 'dometic', 'product_brand' );
	}
	WP_CLI::log( 'Produkt: Dometic Residence AIR (ohne Preis, Originalfotos).' );
}

// Kategoriebild „Vorzelte“: Originalfoto (Residence AIR am Wohnwagen).
$vorzelte = get_term_by( 'slug', 'vorzelte', 'product_cat' );
if ( $vorzelte && ! get_term_meta( $vorzelte->term_id, 'thumbnail_id', true ) ) {
	$photo = $import_image( "{$dir}/residence-air-09.jpg", 'Dometic Residence AIR am Wohnwagen auf einem Campingplatz' );
	if ( $photo ) {
		update_term_meta( $vorzelte->term_id, 'thumbnail_id', $photo );
	}
}

// --- [TEST]-Produkte --------------------------------------------------------------
$green  = $test_image( 'Test Gruen', '#8d9971' );
$orange = $test_image( 'Test Orange', '#e28c59' );
$teal   = $test_image( 'Test Petrol', '#4c747a' );
$img_g  = $import_image( $green, 'Testbild (grün)' );
$img_o  = $import_image( $orange, 'Testbild (orange)' );
$img_t  = $import_image( $teal, 'Testbild (petrol)' );

// Globale Attribute.
$attr = static function ( string $slug, string $label ): int {
	$id = wc_attribute_taxonomy_id_by_name( $slug );
	if ( ! $id ) {
		$id = wc_create_attribute( array( 'name' => $label, 'slug' => $slug, 'type' => 'select', 'order_by' => 'menu_order' ) );
		register_taxonomy( 'pa_' . $slug, array( 'product' ), array() );
	}
	return (int) $id;
};
$attr( 'groesse', 'Größe' );
$attr( 'einsatzbereich', 'Einsatzbereich' );
foreach ( array( 'groesse-1' => 'Größe 1', 'groesse-2' => 'Größe 2', 'groesse-3' => 'Größe 3' ) as $slug => $term ) {
	if ( ! get_term_by( 'slug', $slug, 'pa_groesse' ) ) {
		wp_insert_term( $term, 'pa_groesse', array( 'slug' => $slug ) );
	}
}
foreach ( array( 'reise' => 'Reise', 'saison' => 'Saison' ) as $slug => $term ) {
	if ( ! get_term_by( 'slug', $slug, 'pa_einsatzbereich' ) ) {
		wp_insert_term( $term, 'pa_einsatzbereich', array( 'slug' => $slug ) );
	}
}

$simple = static function ( array $d ) use ( $find, $cat ): int {
	if ( $find( $d['sku'] ) ) {
		return $find( $d['sku'] );
	}
	$p = new WC_Product_Simple();
	$p->set_name( $d['name'] );
	$p->set_sku( $d['sku'] );
	$p->set_status( 'publish' );
	$p->set_short_description( '<p>Testartikel für die lokale Qualitätssicherung (Warenkorb, Kasse, Bestand). Keine echten Produktdaten.</p>' );
	$p->set_description( '<p>Testartikel – keine echten Produktdaten.</p>' );
	$p->set_category_ids( $cat( $d['cat'] ) );
	$p->set_image_id( $d['img'] );
	if ( isset( $d['price'] ) ) {
		$p->set_regular_price( $d['price'] );
	}
	if ( isset( $d['sale'] ) ) {
		$p->set_sale_price( $d['sale'] );
	}
	$p->set_manage_stock( isset( $d['stock'] ) );
	if ( isset( $d['stock'] ) ) {
		$p->set_stock_quantity( $d['stock'] );
	}
	if ( isset( $d['status'] ) ) {
		$p->set_stock_status( $d['status'] );
	}
	$p->set_featured( ! empty( $d['featured'] ) );
	if ( isset( $d['weight'] ) ) {
		$p->set_weight( $d['weight'] );
	}
	if ( isset( $d['umlauf'] ) ) {
		$p->update_meta_data( '_cm_umlauf_min', (string) $d['umlauf'][0] );
		$p->update_meta_data( '_cm_umlauf_max', (string) $d['umlauf'][1] );
	}
	$id = $p->save();
	WP_CLI::log( "Testprodukt: {$d['name']}" );
	return $id;
};

$simple( array( 'name' => '[TEST] Campingstuhl', 'sku' => 'TEST-CS', 'cat' => 'campingmoebel', 'img' => $img_t, 'price' => '49.00', 'stock' => 10, 'featured' => true, 'weight' => '3.2' ) );
$simple( array( 'name' => '[TEST] Sonnendach im Angebot', 'sku' => 'TEST-SD', 'cat' => 'sonnendaecher', 'img' => $img_o, 'price' => '299.00', 'sale' => '249.00', 'stock' => 2, 'featured' => true ) );
$simple( array( 'name' => '[TEST] Zubehör nicht vorrätig', 'sku' => 'TEST-ZB', 'cat' => 'campingzubehoer', 'img' => $img_g, 'price' => '19.90', 'status' => 'outofstock' ) );
$simple( array( 'name' => '[TEST] Dachzelt Preis auf Anfrage', 'sku' => 'TEST-DZ', 'cat' => 'dachzelte', 'img' => $img_t ) );
$simple( array( 'name' => '[TEST] Luftvorzelt einfach', 'sku' => 'TEST-LE', 'cat' => 'luftvorzelte', 'img' => $img_g, 'price' => '1299.00', 'stock' => 4, 'featured' => true, 'umlauf' => array( 840, 870 ) ) );

// Variables Produkt mit drei Größen und eigenem Umlaufmaß je Größe.
if ( ! $find( 'TEST-LV' ) ) {
	$p = new WC_Product_Variable();
	$p->set_name( '[TEST] Luftvorzelt variabel' );
	$p->set_sku( 'TEST-LV' );
	$p->set_status( 'publish' );
	$p->set_short_description( '<p>Testartikel mit drei Größen (eigene Preise, SKUs, Bestände und Umlaufmaße). Keine echten Produktdaten.</p>' );
	$p->set_description( '<p>Testartikel – keine echten Produktdaten.</p>' );
	$p->set_category_ids( $cat( 'luftvorzelte' ) );
	$p->set_image_id( $img_g );
	$p->set_gallery_image_ids( array( $img_o, $img_t ) );
	$p->set_featured( true );

	$size = new WC_Product_Attribute();
	$size->set_id( wc_attribute_taxonomy_id_by_name( 'groesse' ) );
	$size->set_name( 'pa_groesse' );
	$size->set_options( array( 'groesse-1', 'groesse-2', 'groesse-3' ) );
	$size->set_visible( true );
	$size->set_variation( true );

	$use = new WC_Product_Attribute();
	$use->set_id( wc_attribute_taxonomy_id_by_name( 'einsatzbereich' ) );
	$use->set_name( 'pa_einsatzbereich' );
	$use->set_options( array( 'reise' ) );
	$use->set_visible( true );
	$use->set_variation( false );

	$p->set_attributes( array( $size, $use ) );
	$parent = $p->save();
	wp_set_object_terms( $parent, array( 'groesse-1', 'groesse-2', 'groesse-3' ), 'pa_groesse' );
	wp_set_object_terms( $parent, array( 'reise' ), 'pa_einsatzbereich' );

	$variants = array(
		array( 'groesse-1', '899.00', 5, array( 750, 775 ), $img_g ),
		array( 'groesse-2', '949.00', 1, array( 776, 800 ), $img_o ),
		array( 'groesse-3', '999.00', 0, array( 801, 825 ), $img_t ),
	);
	foreach ( $variants as $i => $v ) {
		$var = new WC_Product_Variation();
		$var->set_parent_id( $parent );
		$var->set_attributes( array( 'pa_groesse' => $v[0] ) );
		$var->set_sku( 'TEST-LV-' . ( $i + 1 ) );
		$var->set_regular_price( $v[1] );
		$var->set_manage_stock( true );
		$var->set_stock_quantity( $v[2] );
		$var->set_image_id( $v[4] );
		$var->update_meta_data( '_cm_umlauf_min', (string) $v[3][0] );
		$var->update_meta_data( '_cm_umlauf_max', (string) $v[3][1] );
		$var->save();
	}
	WC_Product_Variable::sync( $parent );
	wc_delete_product_transients( $parent );
	WP_CLI::log( 'Testprodukt: [TEST] Luftvorzelt variabel (3 Größen).' );
}

// Bestände der Testartikel bei jedem Lauf zurücksetzen (Testbestellungen verbrauchen sie).
$stock_reset = array(
	'TEST-CS'   => 10,
	'TEST-SD'   => 2,
	'TEST-LE'   => 4,
	'TEST-LV-1' => 5,
	'TEST-LV-2' => 1,
	'TEST-LV-3' => 0,
);
foreach ( $stock_reset as $sku => $qty ) {
	$product = wc_get_product( $find( $sku ) );
	if ( $product ) {
		wc_update_product_stock( $product, $qty, 'set' );
	}
}
WP_CLI::log( 'Bestände der Testartikel zurückgesetzt.' );

WP_CLI::success( 'Lokale Testdaten bereit.' );

// Bestätigte Kontaktdaten des Betreibers (WhatsApp-Unternehmensprofil): eine Mobilfunknummer
// für Anrufe und WhatsApp. Keine Festnetznummer.
$cm_seed_settings = (array) get_option( 'camp_marl_core_settings', array() );
$cm_seed_settings['phone']    = '+49 1590 1672087';
$cm_seed_settings['whatsapp'] = '+49 1590 1672087';
// Adresse und E-Mail stammen aus der vom Kunden gelieferten Vorlage („Über uns“-Bild) –
// bitte vom Betreiber bestätigen lassen; echte Werte pflegt er unter Einstellungen → CAMP MARL.
$cm_seed_settings['street'] = 'Oelmüllers Feld 32';
$cm_seed_settings['zip']    = '45772';
$cm_seed_settings['city']   = 'Marl';
$cm_seed_settings['email']  = 'info@camp-marl.de';
update_option( 'camp_marl_core_settings', $cm_seed_settings );
