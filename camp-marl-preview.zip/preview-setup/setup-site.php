<?php
/**
 * CAMP MARL – Grundeinrichtung (idempotent, überschreibt keine vorhandenen Inhalte).
 *
 * Aufruf:  wp eval-file dev/setup-site.php
 *
 * Legt fehlende Seiten mit den passenden Templates an, richtet Menüs ein,
 * setzt deutsche WooCommerce-Grundeinstellungen und die Kategorie-Struktur
 * als VORSCHLAG (im Backend jederzeit änderbar).
 *
 * Bewusst NICHT gesetzt (müssen vom Unternehmen kommen): Versandkosten,
 * Zahlungsanbieter-Zugänge, Steuerstatus (Regel-/Kleinunternehmer),
 * Rechtstexte, Firmendaten.
 *
 * @package CampMarl
 */

defined( 'ABSPATH' ) || exit;

$log = static function ( string $msg ): void {
	if ( class_exists( 'WP_CLI' ) ) {
		WP_CLI::log( $msg );
	} else {
		echo esc_html( $msg ) . "\n";
	}
};

/**
 * Seite anlegen, falls es (per Slug) noch keine gibt.
 */
$ensure_page = static function ( string $slug, string $title, string $template = '', string $content = '', string $excerpt = '' ) use ( $log ): int {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		if ( $template && ! get_page_template_slug( $existing ) ) {
			update_post_meta( $existing->ID, '_wp_page_template', $template );
		}
		return (int) $existing->ID;
	}
	$id = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $slug,
			'post_title'   => $title,
			'post_content' => $content,
			'post_excerpt' => $excerpt,
		)
	);
	if ( $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	$log( "Seite angelegt: {$title} (/{$slug}/)" );
	return (int) $id;
};

$legal_placeholder = '<!-- wp:paragraph --><p><strong>[Platzhalter]</strong> Der rechtsverbindliche Text wird von CAMP MARL bzw. der Rechtsberatung bereitgestellt und hier eingefügt. Bitte vor Veröffentlichung ersetzen.</p><!-- /wp:paragraph -->';

// --- Allgemein -------------------------------------------------------------
update_option( 'blogname', 'CAMP MARL' );
update_option( 'blogdescription', 'Draußen beginnt hier – Vorzelte, Markisen und Campingzubehör aus Marl' );
update_option( 'timezone_string', 'Europe/Berlin' );
update_option( 'date_format', 'j. F Y' );
update_option( 'time_format', 'H:i' );
update_option( 'start_of_week', 1 );
update_option( 'WPLANG', 'de_DE' );
update_option( 'permalink_structure', '/%postname%/' );

// --- Seiten -------------------------------------------------------------------
$home    = $ensure_page( 'startseite', 'Startseite' );
$about   = $ensure_page( 'ueber-uns', 'Über uns', 'templates/page-about.php', '<!-- wp:paragraph --><p>[Platzhalter] Hier stellt sich CAMP MARL vor – Geschichte, Team und was euch beim Camping antreibt. Text folgt vom Unternehmen.</p><!-- /wp:paragraph -->' );
$contact = $ensure_page( 'kontakt', 'Kontakt', 'templates/page-contact.php' );
$advice  = $ensure_page( 'beratung', 'Persönliche Beratung für dein Camping-Projekt', 'templates/page-advice.php' );
$finder  = $ensure_page( 'vorzelt-finder', 'Vorzelt-Finder', 'templates/page-finder.php' );
$ship    = $ensure_page( 'versand-und-zahlung', 'Versand & Zahlung', '', $legal_placeholder, 'Versandkosten, Lieferzeiten und Zahlungsarten im Überblick.' );
$imprint = $ensure_page( 'impressum', 'Impressum', '', $legal_placeholder );
$terms   = $ensure_page( 'agb', 'Allgemeine Geschäftsbedingungen', '', $legal_placeholder );
$revoke  = $ensure_page( 'widerrufsbelehrung', 'Widerrufsbelehrung', '', $legal_placeholder );

$privacy_id = (int) get_option( 'wp_page_for_privacy_policy' );
if ( ! $privacy_id || 'publish' !== get_post_status( $privacy_id ) ) {
	$privacy_id = $ensure_page( 'datenschutz', 'Datenschutzerklärung', '', $legal_placeholder );
	update_option( 'wp_page_for_privacy_policy', $privacy_id );
}

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home );

// --- WooCommerce -------------------------------------------------------------
if ( class_exists( 'WooCommerce' ) ) {
	update_option( 'woocommerce_default_country', 'DE' );
	update_option( 'woocommerce_allowed_countries', 'specific' );
	update_option( 'woocommerce_specific_allowed_countries', array( 'DE' ) );
	update_option( 'woocommerce_ship_to_countries', '' );
	update_option( 'woocommerce_currency', 'EUR' );
	update_option( 'woocommerce_currency_pos', 'right_space' );
	update_option( 'woocommerce_price_thousand_sep', '.' );
	update_option( 'woocommerce_price_decimal_sep', ',' );
	update_option( 'woocommerce_price_num_decimals', 2 );
	update_option( 'woocommerce_weight_unit', 'kg' );
	update_option( 'woocommerce_dimension_unit', 'cm' );
	update_option( 'woocommerce_terms_page_id', $terms );
	update_option( 'woocommerce_enable_reviews', 'no' );
	update_option( 'woocommerce_coming_soon', 'no' );
	update_option( 'woocommerce_feature_order_attribution_enabled', 'no' );
	update_option( 'woocommerce_enable_guest_checkout', 'yes' );
	update_option( 'woocommerce_enable_checkout_login_reminder', 'yes' );
	update_option( 'woocommerce_enable_signup_and_login_from_checkout', 'yes' );
	update_option( 'woocommerce_registration_generate_password', 'yes' );
	update_option( 'woocommerce_manage_stock', 'yes' );
	update_option( 'woocommerce_hide_out_of_stock_items', 'no' );
	update_option( 'woocommerce_permalinks', array(
		'product_base'           => '/produkt',
		'category_base'          => 'kategorie',
		'tag_base'               => 'schlagwort',
		'attribute_base'         => '',
		'use_verbose_page_rules' => false,
	) );
	update_option( 'woocommerce_brand_permalink', 'marke' );

	// Deutsche Endpunkte für Kasse und Kundenkonto.
	$endpoints = array(
		'woocommerce_checkout_pay_endpoint'                => 'bezahlen',
		'woocommerce_checkout_order_received_endpoint'     => 'bestellung-erhalten',
		'woocommerce_myaccount_orders_endpoint'            => 'bestellungen',
		'woocommerce_myaccount_view_order_endpoint'        => 'bestellung',
		'woocommerce_myaccount_edit_account_endpoint'      => 'konto-bearbeiten',
		'woocommerce_myaccount_edit_address_endpoint'      => 'adressen',
		'woocommerce_myaccount_payment_methods_endpoint'   => 'zahlungsarten',
		'woocommerce_myaccount_lost_password_endpoint'     => 'passwort-vergessen',
		'woocommerce_logout_endpoint'                      => 'abmelden',
	);
	foreach ( $endpoints as $option => $slug ) {
		update_option( $option, $slug );
	}

	// E-Mail-Design passend zur Marke.
	update_option( 'woocommerce_email_header_image', get_template_directory_uri() . '/assets/images/logo-email.png' );
	update_option( 'woocommerce_email_base_color', '#66744d' );
	update_option( 'woocommerce_email_background_color', '#f6f3ec' );
	update_option( 'woocommerce_email_body_background_color', '#ffffff' );
	update_option( 'woocommerce_email_text_color', '#22271d' );
	update_option( 'woocommerce_email_footer_text', 'CAMP MARL – Draußen beginnt hier · {site_url}' );

	// Seiten-Titel der WooCommerce-Seiten eindeutschen (falls noch englisch).
	$wc_pages = array(
		'shop'      => array( 'Shop', 'shop', 'shop' ),
		'cart'      => array( 'Warenkorb', 'warenkorb', 'cart' ),
		'checkout'  => array( 'Kasse', 'kasse', 'checkout' ),
		'myaccount' => array( 'Mein Konto', 'mein-konto', 'my-account' ),
	);
	foreach ( $wc_pages as $key => $page ) {
		$id = wc_get_page_id( $key );
		if ( $id > 0 ) {
			$update = array( 'ID' => $id, 'post_title' => $page[0] );
			// Englische Standard-Slugs (Installation vor der Übersetzung) eindeutschen.
			if ( get_post_field( 'post_name', $id ) === $page[2] ) {
				$update['post_name'] = $page[1];
			}
			wp_update_post( $update );
		}
	}

	// Kasse: Bestellbutton eindeutig beschriften (§ 312j BGB „Button-Lösung“).
	$checkout_id = wc_get_page_id( 'checkout' );
	if ( $checkout_id > 0 ) {
		$content = (string) get_post_field( 'post_content', $checkout_id );
		if ( str_contains( $content, 'wp:woocommerce/checkout-actions-block' ) && ! str_contains( $content, 'placeOrderButtonLabel' ) ) {
			$content = str_replace( '<!-- wp:woocommerce/checkout-actions-block /-->', '<!-- wp:woocommerce/checkout-actions-block {"placeOrderButtonLabel":"Zahlungspflichtig bestellen"} /-->', $content );
			$content = preg_replace( '#<!-- wp:woocommerce/checkout-actions-block (\{[^}]*\}) -->#', '<!-- wp:woocommerce/checkout-actions-block {"placeOrderButtonLabel":"Zahlungspflichtig bestellen"} -->', $content );
			wp_update_post( array( 'ID' => $checkout_id, 'post_content' => $content ) );
			$log( 'Kasse: Bestellbutton „Zahlungspflichtig bestellen“.' );
		}
	}

	// Kategorie-Struktur (Vorschlag aus Logo & bisheriger Website).
	$cats = array(
		'vorzelte'       => array( 'Vorzelte', 0, 1, 'Luftvorzelte und Anbauten für deinen Wohnwagen – passend zu deinem Umlaufmaß.' ),
		'luftvorzelte'   => array( 'Luftvorzelte', 'vorzelte', 1, '' ),
		'anbauten'       => array( 'Anbauten', 'vorzelte', 2, '' ),
		'markisen'       => array( 'Markisen', 0, 2, 'Markisen und Sonnendächer für Schatten und Wetterschutz.' ),
		'sonnendaecher'  => array( 'Sonnendächer', 'markisen', 1, '' ),
		'dachzelte'      => array( 'Dachzelte', 0, 3, '' ),
		'campingmoebel'  => array( 'Campingmöbel', 0, 4, '' ),
		'campingzubehoer' => array( 'Campingzubehör', 0, 5, '' ),
	);
	foreach ( $cats as $slug => $cat ) {
		if ( term_exists( $slug, 'product_cat' ) ) {
			continue;
		}
		$parent = 0;
		if ( $cat[1] ) {
			$p      = get_term_by( 'slug', $cat[1], 'product_cat' );
			$parent = $p ? (int) $p->term_id : 0;
		}
		$res = wp_insert_term( $cat[0], 'product_cat', array( 'slug' => $slug, 'parent' => $parent, 'description' => $cat[3] ) );
		if ( ! is_wp_error( $res ) ) {
			update_term_meta( $res['term_id'], 'order', $cat[2] );
			$log( "Kategorie: {$cat[0]}" );
		}
	}
	// „Unkategorisiert“ umbenennen.
	$default = get_term( (int) get_option( 'default_product_cat' ), 'product_cat' );
	if ( $default && ! is_wp_error( $default ) && 'Uncategorized' === $default->name ) {
		wp_update_term( $default->term_id, 'product_cat', array( 'name' => 'Ohne Kategorie', 'slug' => 'ohne-kategorie' ) );
	}

	// Marke (tatsächliche Markenbeziehung laut Logo/Unterlagen).
	if ( taxonomy_exists( 'product_brand' ) && ! term_exists( 'dometic', 'product_brand' ) ) {
		wp_insert_term( 'Dometic', 'product_brand', array( 'slug' => 'dometic' ) );
	}
}

// --- Menüs -------------------------------------------------------------------
$make_menu = static function ( string $name, string $location, array $items ) use ( $log ): void {
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( ! empty( $locations[ $location ] ) && wp_get_nav_menu_object( $locations[ $location ] ) ) {
		return;
	}
	$menu_id = wp_create_nav_menu( $name );
	if ( is_wp_error( $menu_id ) ) {
		$menu    = wp_get_nav_menu_object( $name );
		$menu_id = $menu ? $menu->term_id : 0;
	}
	if ( ! $menu_id ) {
		return;
	}
	$add = static function ( array $item, int $parent = 0 ) use ( &$add, $menu_id ): void {
		$args = array( 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent, 'menu-item-title' => $item['title'] ?? '' );
		if ( isset( $item['term'] ) ) {
			$term = get_term_by( 'slug', $item['term'], 'product_cat' );
			if ( ! $term ) {
				return;
			}
			$args += array( 'menu-item-object' => 'product_cat', 'menu-item-object-id' => $term->term_id, 'menu-item-type' => 'taxonomy' );
		} elseif ( isset( $item['page'] ) ) {
			$args += array( 'menu-item-object' => 'page', 'menu-item-object-id' => $item['page'], 'menu-item-type' => 'post_type' );
		} else {
			$args += array( 'menu-item-url' => $item['url'], 'menu-item-type' => 'custom' );
		}
		if ( ! empty( $item['class'] ) ) {
			$args['menu-item-classes'] = $item['class'];
		}
		$id = wp_update_nav_menu_item( $menu_id, 0, $args );
		foreach ( $item['children'] ?? array() as $child ) {
			$add( $child, (int) $id );
		}
	};
	foreach ( $items as $item ) {
		$add( $item );
	}
	$locations[ $location ] = $menu_id;
	set_theme_mod( 'nav_menu_locations', $locations );
	$log( "Menü: {$name}" );
};

// Hauptmenü nach dem Dometic-Katalog – nur bei Neuinstallation (noch kein Menü zugewiesen),
// bestehende Menüs bleiben unangetastet. Zum Aktualisieren: wp eval-file dev/update-main-menu.php
$cm_locations = get_theme_mod( 'nav_menu_locations', array() );
if ( empty( $cm_locations['primary'] ) || ! wp_get_nav_menu_object( $cm_locations['primary'] ) ) {
	require __DIR__ . '/update-main-menu.php';
}

flush_rewrite_rules();
$log( 'Grundeinrichtung abgeschlossen.' );
